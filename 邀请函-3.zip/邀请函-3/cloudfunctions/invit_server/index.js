const cloud = require('wx-server-sdk') // 云开发服务端SDK引入
cloud.init({ // 初始化云开发环境
  env: cloud.DYNAMIC_CURRENT_ENV // 当前环境的常量
})
const db = cloud.database() // 取出数据库操作对象

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext() // 获取微信上下文
  if (event.type === 'get') { // 如果行为是get
    const data = (await db.collection('invit').where({ // 查找数据库集合文档
      _id: wxContext.OPENID // 文档ID为用户的openid
    }).get()).data // 取出data
    if (data.length !== 0) { // 如果取出来有值
      return data[0].status // 返回记录的status值
    } else {
      return 0 // 没有的话，返回0-未提交
    }
  }
  if (event.type === 'add') { // 如果行为是add
    await db.collection('invit').doc(wxContext.OPENID).set({ // 增加设置数据库集合文档，文档ID为用户openid
      data: { // 设置值
        name: event.data.name,
        tel: event.data.tel,
        people: event.data.people,
        retext: event.data.retext,
        status: 1 // 默认为1，1-审核中；2-同意；3-拒绝
      }
    })
    return true // 返回成功
  }
  return false // 没有处理方法，则false
}
