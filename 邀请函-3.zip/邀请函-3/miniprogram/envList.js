const envList = [{"envId":"cloud1-5gh8jvmw0b41c5c5","alias":"cloud1"}]
const isMac = true
module.exports = {
    envList,
    isMac
}